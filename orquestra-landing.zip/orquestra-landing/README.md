# Orquestra landing page
Next.js 15 + TypeScript + Tailwind + Framer Motion.

    npm install
    npm run dev

Deploy: push to GitHub, import the repo in Vercel, click Deploy.
