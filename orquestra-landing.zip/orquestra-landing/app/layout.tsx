import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", weight: ["500", "900"] });

export const metadata: Metadata = {
  title: "Orquestra | The AI Operating System for Modern Businesses",
  description: "Sales, inventory, customers and operations in one intelligent platform.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${inter.variable} font-sans font-medium antialiased`}>{children}</body>
    </html>
  );
}
