const cols = {
  Product: ["CRM", "Inventory", "Sales", "Analytics", "AI Copilot"],
  Company: ["About", "Careers", "Contact"],
  Legal: ["Privacy", "Terms", "Security"],
};

export default function Footer() {
  return (
    <footer className="border-t border-white/10 px-6 py-16">
      <div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-4">
        <div>
          <p className="text-lg font-black">Orquestra</p>
          <p className="mt-3 max-w-xs text-sm text-sub">The AI operating system for modern businesses.</p>
        </div>
        {Object.entries(cols).map(([h, items]) => (
          <div key={h}>
            <p className="font-black">{h}</p>
            <ul className="mt-4 space-y-2 text-sm text-sub">
              {items.map((i) => (<li key={i}><a href="#" className="transition hover:text-white">{i}</a></li>))}
            </ul>
          </div>
        ))}
      </div>
      <p className="mx-auto mt-12 max-w-7xl text-sm text-sub">© {new Date().getFullYear()} Orquestra. All rights reserved.</p>
    </footer>
  );
}
