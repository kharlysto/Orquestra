const links = [["Problem", "#problem"], ["Features", "#features"], ["Preview", "#preview"], ["Pricing", "#pricing"]];

export default function Navbar() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/5 bg-bg/70 backdrop-blur-xl">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <a href="#" className="flex items-center gap-2 text-lg font-black tracking-tight">
          <span className="h-3 w-3 rounded-full bg-primary shadow-[0_0_14px_#00E5C2]" />
          Orquestra
        </a>
        <ul className="hidden gap-8 text-sm text-sub md:flex">
          {links.map(([l, h]) => (
            <li key={h}><a href={h} className="transition hover:text-white">{l}</a></li>
          ))}
        </ul>
        <a href="/login" className="rounded-full bg-primary px-5 py-2 text-sm font-black text-bg transition hover:bg-secondary">
          Start free
        </a>
      </nav>
    </header>
  );
}
