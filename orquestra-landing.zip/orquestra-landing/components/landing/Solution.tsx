const features = [
  ["CRM", "Every customer, their purchase history and total revenue in one profile."],
  ["Inventory", "Track stock by product and get warned before you run out."],
  ["Sales", "Record a sale, update stock and print the receipt in one step."],
  ["Analytics", "Weekly and monthly revenue, best sellers and growth at a glance."],
  ["AI Copilot", "Ask your business a question and get an answer from your own data."],
];

export default function Solution() {
  return (
    <section id="features" className="px-6 py-28">
      <div className="mx-auto max-w-7xl">
        <h2 className="max-w-3xl text-4xl font-black tracking-tight sm:text-6xl">
          Not another dashboard. An intelligent operating system.
        </h2>
        <p className="mt-6 max-w-2xl text-lg text-sub">
          Orquestra connects what you sell, who buys it and what is left on the shelf, then lets an AI conduct the rest.
        </p>
        <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-6">
          {features.map(([t, d], i) => (
            <div key={t}
              className={`group rounded-3xl border border-white/10 bg-card p-8 transition hover:border-primary/50 ${i === 4 ? "lg:col-span-6 border-primary/30" : i < 3 ? "lg:col-span-2" : "lg:col-span-3"}`}>
              <h3 className="text-2xl font-black">{t}</h3>
              <p className="mt-3 max-w-md text-sub">{d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
